drop database users if exists users;
create database users default character set utf8;
use users;

drop table if exists users;
create table users(
	id varchar(32) primary key not null,
	userName varchar(20) not null,
	userPwd varchar(20) not null,
	email varchar(20),
	registerdate datetime
);
