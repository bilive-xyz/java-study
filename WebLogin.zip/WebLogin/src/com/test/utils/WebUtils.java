package com.test.utils;

import java.util.Enumeration;
import java.util.UUID;
import javax.servlet.http.HttpServletRequest;
import org.apache.commons.beanutils.BeanUtils;

/**
 * 把request对象中的请求参数封装到formbean中
 *
 */
public class WebUtils {
	public static<T> T requestBean(HttpServletRequest request,Class<T> clazz){
		try{
			//创建指定类型的bean
			T bean=clazz.newInstance();
			//遍历获取属性名称和值，放到bean中
			Enumeration<String> e=request.getParameterNames();
			while(e.hasMoreElements()){
				String name=(String)e.nextElement();
				String value=request.getParameter(name);
				BeanUtils.setProperty(bean, name, value);
			}
			return bean;
		}catch(Exception e){
			throw new RuntimeException(e);
		}
		
	}
	//生成随机id
	public static String makeId(){
		return UUID.randomUUID().toString();
	}

}
