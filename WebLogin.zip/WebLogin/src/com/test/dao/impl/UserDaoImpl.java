package com.test.dao.impl;

import java.text.SimpleDateFormat;
import java.util.Date;

import com.test.dao.UserDao;
import com.test.domain.User;


public class UserDaoImpl extends BaseQueryImpl implements UserDao{

	@Override
	public User find(String userName) {
		String sql="select * from users where userName='"+userName+"'";
		return query(sql);
	}

	@Override
	public User find(String userName, String userPwd) {
		String sql="select * from users where userName='"+userName+"' and userPwd='"+userPwd+"'";
		return query(sql);
	}

	@Override
	public void add(User user) {
		SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		String sql="insert into users(id,userName,userPwd,email,registerdate) values('"+user.getId()+"'," +
				"'"+user.getUserName()+"','"+user.getUserPwd()+"','"+user.getEmail()+"','"+sdf.format(new Date())+"')";
		adduser(sql);
		
	}

}
