package com.test.dao.impl;

import java.sql.ResultSet;
import java.sql.SQLException;

import com.test.domain.User;
import com.test.utils.DBManager;

public abstract class BaseQueryImpl {
	DBManager db=new DBManager();
	public User query(String sql){
		ResultSet rs=db.executeQuery(sql);
		try{
			if((rs!=null)&&(rs.next())){
				User user=new User();
				user.setId(rs.getString("id"));
				user.setUserName(rs.getString("userName"));
				user.setUserPwd(rs.getString("userPwd"));
				user.setEmail(rs.getString("email"));
				user.setRegisterdate(rs.getDate("registerdate"));
				return user;
			}

		}catch(SQLException e){
			e.printStackTrace();
		}
		return null;	
	}
	public void adduser(String sql){
		System.out.print(sql);
		db.executeUpdate(sql);
	}

}
