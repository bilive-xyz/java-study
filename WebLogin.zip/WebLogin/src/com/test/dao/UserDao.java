package com.test.dao;

import com.test.domain.User;

public interface UserDao {
	
	//根据用户名查找用户
	public User find(String userName);
	//根据用户名和密码来查找用户
	public User find(String userName,String userPwd);
	//添加用户
	public void add(User user);
	
}
