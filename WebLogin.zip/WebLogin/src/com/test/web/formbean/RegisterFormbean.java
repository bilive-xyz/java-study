package com.test.web.formbean;

import java.util.HashMap;
import java.util.Map;

public class RegisterFormbean {
	private String userName;
	private String userPwd;
	private String confirmPwd;
	private String email;
	private String registerdate;
	
	/**
	 * 存储校验不通过时给用户的错误提示
	 */
	private Map<String,String> errors=new HashMap<String,String>();
	public Map<String, String> getErrors() {
		return errors;
	}
	public void setErrors(Map<String, String> errors) {
		this.errors = errors;
	}
	
	/**
	 * validate方法负责校验表单输入项
	 * 表单输入规则如下：
	 * 		userName:用户名不能为空，并且要是3-8位的字母
	 * 		userPwd:密码不能为空，并且要是3-8位数字或字母
	 * 		confirmPwd:两次密码要一致
	 * 		email:可以为空，不为空时是一个合法的邮箱
	 */
	public boolean validate(){
		boolean isOk=true;
		if(this.userName==null||this.userName.trim().equals("")){
			isOk=false;
			errors.put("userName", "用户名不能为空！");
		}else{
			if(!this.userName.matches("[a-zA-Z]{3,8}")){
				isOk=false;
				errors.put("userName", "用户名必须是3-8位的字母！");
			}
		}
		
		if(this.userPwd==null || this.userPwd.trim().equals("")){
			isOk=false;
			errors.put("userPwd", "密码不能为空！");
		}else{
			if(!this.userPwd.matches("[a-zA-z0-9]{3,8}")){
				isOk=false;
				errors.put("userPwd", "密码必须是3-8位的数字或字母！");
			}
		}
		if(this.confirmPwd!=null){
			if(!this.confirmPwd.equals(this.userPwd)){
				isOk=false;
				errors.put("confirmPwd", "两次密码不一致！");
			}
		}
		if(this.email!=null && !this.email.trim().equals("")){
			if(!this.email.matches("\\w+@\\w+(\\.\\w+)+")){
				isOk=false;
				errors.put("email", "邮箱格式非法！");
			}
		}
		return isOk;	
	}
	
	
	
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getUserPwd() {
		return userPwd;
	}
	public void setUserPwd(String userPwd) {
		this.userPwd = userPwd;
	}
	public String getConfirmPwd() {
		return confirmPwd;
	}
	public void setConfirmPwd(String confirmPwd) {
		this.confirmPwd = confirmPwd;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getRegisterdate() {
		return registerdate;
	}
	public void setRegisterdate(String registerdate) {
		this.registerdate = registerdate;
	}
	

}
