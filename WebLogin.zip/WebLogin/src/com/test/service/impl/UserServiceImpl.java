package com.test.service.impl;

import com.test.dao.UserDao;
import com.test.dao.impl.UserDaoImpl;
import com.test.domain.User;
import com.test.exception.UserExistException;
import com.test.service.UserService;

public class UserServiceImpl implements UserService{
	
	private UserDao userDao=new UserDaoImpl();

	@Override
	public void registerUser(User user) throws UserExistException {
		if(userDao.find(user.getUserName())!=null){
			throw new UserExistException("注册的用户名已存在！");
		}
		userDao.add(user);
	}

	@Override
	public User login(String userName, String userPwd) {
		return userDao.find(userName, userPwd);
	}

}
