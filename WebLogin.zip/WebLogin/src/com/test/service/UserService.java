package com.test.service;

import com.test.domain.User;
import com.test.exception.UserExistException;

public interface UserService {
	//用户注册
	public void registerUser(User user) throws UserExistException;
	//登录
	public User login(String userName,String userPwd);

}
